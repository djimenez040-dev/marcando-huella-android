package com.ebc.marcandohuella
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.ebc.marcandohuella.ui.MarcandoHuellaApp
import com.ebc.marcandohuella.ui.theme.MarcandoHuellaTheme
// Esta es la actividad que se abre al iniciar la app.
class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  // Permite que la pantalla use el espacio de las barras del sistema.
  enableEdgeToEdge()
  // Muestra la app con los colores de Marcando Huella.
  setContent { MarcandoHuellaTheme { MarcandoHuellaApp() } }
 }
}
