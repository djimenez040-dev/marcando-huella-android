# Marcando Huella en Android Studio

Aplicación Kotlin con Jetpack Compose, adaptada del flujo por pasos de MuffinShop.

## Qué incluye

- Las 17 figuras del catálogo web, $110 MXN por placa y las 12 tipografías reales sin conexión.
- Colores del sitio: fondo #070B0D, superficie #101719, superficie secundaria #172124, turquesa #0EE1E5, azul #609DF3 y texto #F7FAF9.
- Flujo: figura → nombre y tipografía → cantidad → cliente → resumen → WhatsApp.
- Búsqueda, categorías, vista previa del nombre, validación y borrador persistente local.
- Cada solicitud configura un único diseño con una cantidad. Para otra mascota o figura, termina la consulta y reinicia. No es un carrito con varios diseños.
- Sin imágenes, pagos ni servidor. El nombre es el único dato que se graba, como en el sitio; teléfono y correo pertenecen al cliente.

## Opción recomendada para abrirlo completo

1. Descomprime MarcandoHuella_Android.zip en una carpeta de tu elección.
2. Android Studio → Open → selecciona la carpeta MarcandoHuella que contiene settings.gradle.kts.
3. Espera Gradle Sync. Usa el JDK integrado de Android Studio como Gradle JDK.
4. Si se solicita, instala la plataforma SDK de compilación 37 y acepta sus licencias desde SDK Manager. Se conservan las versiones del proyecto MuffinShop revisado: AGP 9.4.1, Gradle 9.6.0 y plugin Compose 2.2.10.
5. Selecciona un emulador o dispositivo Android 7.0 o superior y pulsa Run.
6. Si Android Studio pide la ubicación del SDK, selecciona el SDK instalado en tu computadora. No se distribuye local.properties porque contiene una ruta específica de cada equipo.

**Compatibilidad:** minSdk = 24 corresponde a Nougat 7.0 y también admite Nougat 7.1 API 25. compileSdk y targetSdk no se deben cambiar a 24: son parámetros diferentes y las librerías modernas necesitan un SDK de compilación más reciente.

## Opción para copiar y pegar en un proyecto nuevo

1. Crea un proyecto Empty Activity con Compose, lenguaje Kotlin, nombre MarcandoHuella y paquete com.ebc.marcandohuella. Elige API mínima 24.
2. Para reproducir exactamente esta configuración, usa los archivos Gradle y la carpeta gradle del ZIP. No mezcles su catálogo de versiones con otro build.gradle.kts de una plantilla distinta.
3. En la vista Project, entra en app/src/main/java/com/ebc/marcandohuella. Aunque la carpeta se llame java, los archivos de esta app son Kotlin.
4. Crea los paquetes model, viewmodel, ui y ui.theme con New → Package. En cada paquete crea New → Kotlin Class/File → File con los nombres de la tabla siguiente. Copia el bloque completo correspondiente. Si prefieres Class para MainActivity o PedidoViewModel, reemplaza también el contenido generado, incluida la línea package.
5. Reemplaza MainActivity.kt de la plantilla. No dejes dos clases MainActivity en el mismo paquete.
6. En res/values crea o reemplaza los XML indicados con New → Values Resource File. Si tu plantilla tiene values-night/themes.xml con el mismo estilo, unifica el nombre Theme.MarcandoHuella para evitar que se use otro tema por la noche.
7. Copia los 12 archivos .ttf del ZIP a app/src/main/res/font. Los archivos de fuente son binarios y no se pueden generar pegando código. El paquete incluye Caveat y Montserrat convertidas a fuentes estáticas para Nougat. Conserva FUENTES con sus avisos y licencia.
8. Sincroniza Gradle y ejecuta.

## Qué tipo de archivo crear

| Ruta desde la raíz del proyecto | Tipo en Android Studio | Función |
| --- | --- | --- |
| app/src/main/java/com/ebc/marcandohuella/MainActivity.kt | Kotlin Class o Kotlin File | Inicia la app y aplica el tema |
| app/src/main/java/com/ebc/marcandohuella/model/Catalogo.kt | Kotlin File | Pieza, Letra y objeto Catalogo con los datos del sitio |
| app/src/main/java/com/ebc/marcandohuella/model/Pedido.kt | Kotlin File o Data Class | Datos, validación, costo y resumen |
| app/src/main/java/com/ebc/marcandohuella/viewmodel/PedidoViewModel.kt | Kotlin Class | Estado, pasos y guardado del borrador |
| app/src/main/java/com/ebc/marcandohuella/ui/MarcandoHuellaApp.kt | Kotlin File | Pantallas Compose, navegación por pasos y WhatsApp |
| app/src/main/java/com/ebc/marcandohuella/ui/theme/Theme.kt | Kotlin File | Paleta y tema Compose |
| app/src/main/AndroidManifest.xml | XML existente | Registra la actividad principal |
| app/src/main/res/values/strings.xml | Values Resource File XML | Nombre de la app |
| app/src/main/res/values/themes.xml | Values Resource File XML | Tema Android y barras del sistema |
| app/src/main/res/font/*.ttf | Font resource binario | Fuentes de los nombres de las mascotas |
| app/build.gradle.kts | Gradle Kotlin DSL existente | SDK y dependencias del módulo |
| build.gradle.kts | Gradle Kotlin DSL existente | Plugins raíz |
| settings.gradle.kts | Gradle Kotlin DSL existente | Repositorios y módulos |
| gradle/libs.versions.toml | Archivo TOML existente | Catálogo de versiones |

No crees Java Classes, archivos de layout XML, fragments ni imágenes drawable para esta versión. Compose dibuja las pantallas mediante funciones @Composable. No se necesita permiso INTERNET para abrir una aplicación externa con un Intent.

## Configurar WhatsApp

En ui/MarcandoHuellaApp.kt encontrarás:

```kotlin
private const val WHATSAPP_NEGOCIO = ""
```

Déjalo vacío para elegir destinatario, como en la web. Para un destinatario fijo escribe el número comercial real con código de país, solo dígitos y sin + ni espacios. No se inventó un número del negocio. El usuario revisa el mensaje y pulsa Enviar dentro de WhatsApp; la app no envía mensajes automáticamente ni confirma pedidos. Si no hay una app que abra el enlace, puede copiar el resumen.

## Vista previa en Android Studio

Abre ui/MarcandoHuellaApp.kt y selecciona Split o Design. Hay cinco funciones @Preview al final del archivo: FiguraPreview, PersonalizacionPreview, CantidadPreview, ClientePreview y ResumenPreview. Pulsa Build and Refresh si Android Studio lo solicita. No añadas @Preview a MarcandoHuellaApp: esa función crea el ViewModel real. Las funciones Preview usan MarcandoHuellaContenido con datos de ejemplo, sin SharedPreferences ni creación de ViewModel. El modo interactivo permite cambiar los datos de ejemplo; WhatsApp se debe probar desde Run en un dispositivo.

Si el panel continúa fallando, abre sus detalles de Render Problems o Problems y copia el mensaje completo. La compilación verifica el código, pero no confirma que el motor de renderizado del IDE funcione en cada instalación.

## Datos y validaciones

- Figura obligatoria y tipografía seleccionable entre 12 opciones.
- Nombre a grabar de 1 a 18 caracteres, sin saltos de línea. A diferencia de la web, no acepta una placa sin nombre.
- Cantidad de 1 a 99; precio unitario centralizado en Catalogo.PRECIO.
- Nombre de cliente obligatorio, teléfono mexicano de 10 dígitos y correo válido.
- Cada cambio se guarda en SharedPreferences privadas de la app. Se recupera el borrador incluso al cerrar y volver a abrir; se comienza en el primer paso para revisarlo. La rotación conserva el paso mediante ViewModel. Reiniciar pide confirmación y borra la solicitud.
- El precio viene del código local, y el total se presenta como estimado. Medidas, acabados, envío y precio final se confirman con el negocio.
- No se capturan datos adicionales de grabado porque no estaban presentes en el configurador original.

## Diferencias corregidas respecto a MuffinShop

La MainActivity revisada todavía mostraba Greeting con Hello Android; ahora abre MarcandoHuellaApp. El AlertDialog estaba fuera de una condición y aparecía siempre; ahora solo aparece al pulsar Reiniciar. Se eliminaron rutas de prueba, textos de depuración y librerías innecesarias para esta app. La pantalla final no afirma que el pedido fue enviado porque abrir WhatsApp no permite comprobarlo.

## Prueba manual recomendada

1. Buscar hueso y comprobar que el filtro reduce la lista. Limpiar y elegir Redondo mediano.
2. Intentar continuar con nombre vacío: Siguiente debe estar desactivado.
3. Escribir Luna, cambiar entre las 12 letras y comprobar que la vista previa cambia.
4. Elegir tres placas: el total debe ser $330 MXN.
5. Capturar nombre, teléfono de 10 dígitos y correo. Un correo incorrecto no debe permitir continuar.
6. Volver con Regresar o con el botón del sistema: los datos deben conservarse.
7. Rotar y cerrar/reabrir la app: revisar la conservación del borrador.
8. Copiar el resumen y abrir WhatsApp. Comprobar figura, nombre, letra, cantidad, total y datos del cliente antes de enviar.
9. Cancelar el diálogo de reinicio debe conservar el borrador; confirmarlo debe vaciarlo.
10. Ejecutar esta prueba también en un emulador API 24 para verificar el comportamiento en Nougat.

## Referencias técnicas

- Android Nougat y API 24: https://developer.android.com/about/versions/nougat/android-7.0-changes
- Configuración de Compose: https://developer.android.com/develop/ui/compose/setup

## Código completo por archivo

Los siguientes bloques se pueden copiar completos. Mantén las rutas y el paquete com.ebc.marcandohuella. El ZIP ya contiene estos mismos archivos y las fuentes.

### Comprobaciones realizadas

Se ejecutaron assembleDebug y testDebugUnitTest con resultado BUILD SUCCESSFUL. Las cuatro pruebas verifican catálogo y fuentes, costo de tres piezas, validación de la placa y contenido del resumen. El APK generado declara minSdk 24 y targetSdk 37. No había un emulador o dispositivo conectado, por lo que queda pendiente la prueba visual e interacción en Android Nougat.

El archivo app/src/test/java/com/ebc/marcandohuella/PedidoTest.kt es un Kotlin File de pruebas, fuera de src/main. Puedes ejecutarlo con Run sobre PedidoTest en Android Studio. Es opcional para ejecutar la app, pero está incluido para verificar su lógica.

### build.gradle.kts

```kotlin
// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose) apply false
}
```

### settings.gradle.kts

```kotlin
pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0"
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "MarcandoHuella"
include(":app")
```

### gradle.properties

```properties
# Project-wide Gradle settings.
# IDE (e.g. Android Studio) users:
# Gradle settings configured through the IDE *will override*
# any settings specified in this file.
# For more details on how to configure your build environment visit
# http://www.gradle.org/docs/current/userguide/build_environment.html
# Specifies the JVM arguments used for the daemon process.
# The setting is particularly useful for tweaking memory settings.
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
# When configured, Gradle will run in incubating parallel mode.
# This option should only be used with decoupled projects. For more details, visit
# https://developer.android.com/r/tools/gradle-multi-project-decoupled-projects
# org.gradle.parallel=true
# When enabled, the Configuration Cache allows Gradle to skip the configuration
# phase entirely if nothing that affects the build configuration (such as build scripts)
# has changed. Additionally, Gradle applies performance optimizations to task execution.
org.gradle.configuration-cache=true
# Kotlin code style for this project: "official" or "obsolete":
kotlin.code.style=official
```

### gradle/libs.versions.toml

```toml
[versions]
agp = "9.4.1"
coreKtx = "1.19.1"
junit = "4.13.2"
junitVersion = "1.3.0"
espressoCore = "3.7.0"
lifecycleRuntimeKtx = "2.11.0"
activityCompose = "1.13.0"
kotlin = "2.2.10"
composeBom = "2026.02.01"
material3 = "1.4.0"

[libraries]
androidx-core-ktx = { group = "androidx.core", name = "core-ktx", version.ref = "coreKtx" }
junit = { group = "junit", name = "junit", version.ref = "junit" }
androidx-junit = { group = "androidx.test.ext", name = "junit", version.ref = "junitVersion" }
androidx-espresso-core = { group = "androidx.test.espresso", name = "espresso-core", version.ref = "espressoCore" }
androidx-lifecycle-runtime-ktx = { group = "androidx.lifecycle", name = "lifecycle-runtime-ktx", version.ref = "lifecycleRuntimeKtx" }
androidx-activity-compose = { group = "androidx.activity", name = "activity-compose", version.ref = "activityCompose" }
androidx-compose-bom = { group = "androidx.compose", name = "compose-bom", version.ref = "composeBom" }
androidx-compose-ui = { group = "androidx.compose.ui", name = "ui" }
androidx-compose-ui-graphics = { group = "androidx.compose.ui", name = "ui-graphics" }
androidx-compose-ui-tooling = { group = "androidx.compose.ui", name = "ui-tooling" }
androidx-compose-ui-tooling-preview = { group = "androidx.compose.ui", name = "ui-tooling-preview" }
androidx-compose-ui-test-manifest = { group = "androidx.compose.ui", name = "ui-test-manifest" }
androidx-compose-ui-test-junit4 = { group = "androidx.compose.ui", name = "ui-test-junit4" }
androidx-compose-material3 = { group = "androidx.compose.material3", name = "material3" }
androidx-material3 = { group = "androidx.compose.material3", name = "material3", version.ref = "material3" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-compose = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }
```

### gradle/wrapper/gradle-wrapper.properties

```properties
#Wed Oct 21 19:50:42 CST 2026
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionSha256Sum=bbaeb2fef8710818cf0e261201dab964c572f92b942812df0c3620d62a529a01
distributionUrl=https\://services.gradle.org/distributions/gradle-9.6.0-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
```

### app/build.gradle.kts

```kotlin
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.ebc.marcandohuella"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "com.ebc.marcandohuella"
        minSdk = 24
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = false
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    testImplementation(libs.junit)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
    debugImplementation(libs.androidx.compose.ui.tooling)

    // LibrerÃ­as extra
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.11.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.11.0")

}
```

### app/src/main/AndroidManifest.xml

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
 <application android:allowBackup="false" android:label="@string/app_name" android:theme="@style/Theme.MarcandoHuella" android:supportsRtl="true">
  <activity android:name=".MainActivity" android:exported="true" android:windowSoftInputMode="adjustResize">
   <intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter>
  </activity>
 </application>
</manifest>
```

### app/src/main/res/values/strings.xml

```xml
<resources><string name="app_name">Marcando Huella</string></resources>
```

### app/src/main/res/values/themes.xml

```xml
<resources><style name="Theme.MarcandoHuella" parent="android:style/Theme.Material.NoActionBar">
 <item name="android:fontFamily">sans</item><item name="android:windowLightStatusBar">false</item>
 <item name="android:statusBarColor">#070B0D</item><item name="android:navigationBarColor">#070B0D</item>
 <item name="android:windowActionModeOverlay">true</item><item name="android:colorAccent">#0EE1E5</item>
</style></resources>
```

### app/src/main/java/com/ebc/marcandohuella/MainActivity.kt

```kotlin
package com.ebc.marcandohuella
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.ebc.marcandohuella.ui.MarcandoHuellaApp
import com.ebc.marcandohuella.ui.theme.MarcandoHuellaTheme
// Esta es la actividad que se abre al iniciar la app.
class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  // Permite que la pantalla use el espacio de las barras del sistema.
  enableEdgeToEdge()
  // Muestra la app con los colores de Marcando Huella.
  setContent { MarcandoHuellaTheme { MarcandoHuellaApp() } }
 }
}
```

### app/src/main/java/com/ebc/marcandohuella/model/Catalogo.kt

```kotlin
package com.ebc.marcandohuella.model
import com.ebc.marcandohuella.R
// Guarda los datos de cada figura.
data class Pieza(val id: String, val nombre: String, val categoria: String)
// Relaciona el nombre de la tipografía con su archivo de fuente.
data class Letra(val nombre: String, val recurso: Int)
object Catalogo {
 // Todas las placas tienen el mismo precio por pieza.
 const val PRECIO = 110
 // Lista de las figuras que se pueden elegir.
 val piezas = listOf(
  Pieza("redondo-chico-corazon", "Redondo chico con corazón troquelado", "troquelada"),
  Pieza("hueso-largo-huella", "Hueso largo con huella troquelada", "troquelada"),
  Pieza("rombo", "Rombo", "clasica"),
  Pieza("estrella", "Estrella", "clasica"),
  Pieza("hueso-grande-huella", "Hueso grande con huella troquelada", "troquelada"),
  Pieza("hueso-grande", "Hueso grande", "clasica"),
  Pieza("ovalo", "Óvalo", "clasica"),
  Pieza("ovalo-corazon", "Óvalo con corazón troquelado", "troquelada"),
  Pieza("hueso-largo", "Hueso largo", "clasica"),
  Pieza("hueso-chico", "Hueso chico", "clasica"),
  Pieza("corazon-mediano", "Corazón mediano", "clasica"),
  Pieza("corazon-chico", "Corazón chico", "clasica"),
  Pieza("redondo-grande", "Redondo grande", "clasica"),
  Pieza("redondo-mediano", "Redondo mediano", "clasica"),
  Pieza("pez", "Pez", "animal"),
  Pieza("gato-bigotes", "Gato con bigotes", "animal"),
  Pieza("gato-sin-bigotes", "Gato sin bigotes", "animal")
 )
 // Lista de las 12 tipografías para el nombre de la mascota.
 val letras = listOf(
  Letra("Alex Brush", R.font.alex_brush),
  Letra("Oregano", R.font.oregano),
  Letra("Gloria Hallelujah", R.font.gloria_hallelujah),
  Letra("Shadows Into Light", R.font.shadows_into_light),
  Letra("Allura", R.font.allura),
  Letra("Antonio", R.font.antonio),
  Letra("Caveat", R.font.caveat),
  Letra("Mogra", R.font.mogra),
  Letra("Sacramento", R.font.sacramento),
  Letra("Montserrat", R.font.montserrat),
  Letra("Neucha", R.font.neucha),
  Letra("Euphoria Script", R.font.euphoria_script)
 )
}
```

### app/src/main/java/com/ebc/marcandohuella/model/Pedido.kt

```kotlin
package com.ebc.marcandohuella.model
// Guarda la placa elegida y los datos del cliente.
data class Pedido(
 val pieza: Int = -1, val mascota: String = "", val letra: Int = 0,
 val cantidad: Int = 1, val nombre: String = "", val telefono: String = "", val correo: String = ""
) {
 // Calcula el total según la cantidad de placas.
 val total: Int get() = cantidad * Catalogo.PRECIO
 // Revisa que se haya elegido una figura, un nombre y una letra válida.
 val placaValida: Boolean get() = pieza in Catalogo.piezas.indices && mascota.trim().length in 1..18 && letra in Catalogo.letras.indices
 // Revisa el nombre del cliente, el teléfono y el correo.
 val clienteValido: Boolean get() = nombre.trim().isNotEmpty() && telefono.length == 10 && android.util.Patterns.EMAIL_ADDRESS.matcher(correo.trim()).matches()
 // Prepara el texto que se puede copiar o enviar por WhatsApp.
 fun resumen(): String = buildString {
  appendLine("Hola, quiero cotizar placas de Marcando Huella:")
  appendLine("Figura: ${Catalogo.piezas.getOrNull(pieza)?.nombre.orEmpty()}")
  appendLine("Nombre a grabar: ${mascota.trim()}")
  appendLine("Tipografía: ${Catalogo.letras.getOrNull(letra)?.nombre.orEmpty()}")
  appendLine("Cantidad: $cantidad")
  appendLine("Precio por pieza: $${Catalogo.PRECIO} MXN")
  appendLine("Total estimado: $$total MXN")
  appendLine("Cliente: ${nombre.trim()}")
  appendLine("Teléfono: $telefono")
  appendLine("Correo: ${correo.trim()}")
  append("¿Me ayudan a confirmar medidas, acabados, disponibilidad y costo final?")
 }
}
```

### app/src/main/java/com/ebc/marcandohuella/ui/MarcandoHuellaApp.kt

```kotlin
package com.ebc.marcandohuella.ui

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.tooling.preview.Preview
import com.ebc.marcandohuella.model.Pedido
import com.ebc.marcandohuella.ui.theme.MarcandoHuellaTheme
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ebc.marcandohuella.model.Catalogo
import com.ebc.marcandohuella.viewmodel.PedidoViewModel

// Vacío conserva el comportamiento del sitio: el usuario elige el destinatario.
// Para dirigir al negocio: código de país y número, sin + ni espacios.
private const val WHATSAPP_NEGOCIO = ""

@Composable
// Dibuja una tarjeta que se puede seleccionar.
private fun Opcion(titulo: String, detalle: String, seleccionada: Boolean, click: () -> Unit) {
    Card(
        onClick = click,
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(if (seleccionada) 2.dp else 1.dp,
            if (seleccionada) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
    ) {
        Row(Modifier.padding(12.dp)) {
            RadioButton(selected = seleccionada, onClick = null)
            Column(Modifier.padding(start = 8.dp).weight(1f)) {
                Text(titulo, style = MaterialTheme.typography.titleMedium)
                Text(detalle, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
// Conecta los datos del ViewModel con las pantallas.
fun MarcandoHuellaApp(vm: PedidoViewModel = viewModel()) {
    MarcandoHuellaContenido(
        p = vm.pedido,
        paso = vm.paso,
        actualizar = vm::actualizar,
        ir = vm::ir,
        reiniciar = vm::reiniciar
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
// Muestra el contenido y recibe las acciones para cambiar los datos.
private fun MarcandoHuellaContenido(
    p: Pedido,
    paso: Int,
    actualizar: (Pedido) -> Unit,
    ir: (Int) -> Unit,
    reiniciar: () -> Unit
) {
    val context = LocalContext.current
    val titulos = listOf("Elige una figura", "Personaliza la placa", "Cantidad", "Datos del cliente", "Revisa tu solicitud")
    // Controla si se muestra la pregunta para reiniciar.
    var cancelar by rememberSaveable { mutableStateOf(false) }
    // Guarda el texto de búsqueda y la categoría seleccionada.
    var busqueda by rememberSaveable { mutableStateOf("") }
    var categoria by rememberSaveable { mutableStateOf("Todas") }
    val categorias = listOf("Todas", "clasica", "troquelada", "animal")
    // Activa el botón de regresar del celular cuando la app está en ejecución.
    if (!LocalInspectionMode.current) {
        BackHandler(enabled = paso > 0) { ir(paso - 1) }
    }
    // Pide confirmación antes de borrar la solicitud.
    if (cancelar) {
        AlertDialog(
            onDismissRequest = { cancelar = false },
            title = { Text("¿Reiniciar solicitud?") },
            text = { Text("Se borrarán la selección y los datos guardados en este dispositivo.") },
            confirmButton = { TextButton(onClick = {
                reiniciar(); busqueda = ""; categoria = "Todas"; cancelar = false
            }) { Text("Sí, reiniciar") } },
            dismissButton = { TextButton(onClick = { cancelar = false }) { Text("Continuar") } }
        )
    }
    // Decide si se puede continuar al siguiente paso.
    val valido = when (paso) {
        0 -> p.pieza in Catalogo.piezas.indices
        1 -> p.placaValida
        2 -> p.cantidad in 1..99
        3, 4 -> p.placaValida && p.clienteValido
        else -> false
    }
    // Organiza la barra superior, los botones y el contenido.
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Marcando Huella", fontSize = 20.sp) },
                actions = { TextButton(onClick = { cancelar = true }) { Text("Reiniciar") } })
        },
        // Muestra el total y los botones para regresar o continuar.
        bottomBar = {
            Surface {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(12.dp)) {
                    Text("Total estimado: $${p.total} MXN", color = MaterialTheme.colorScheme.primary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { ir(paso - 1) }, enabled = paso > 0, modifier = Modifier.weight(1f)) {
                            Text("Regresar")
                        }
                        Button(onClick = {
                            if (paso < 4) ir(paso + 1)
                            else abrirWhatsApp(context, p.resumen())
                        }, enabled = valido, modifier = Modifier.weight(1f)) {
                            Text(if (paso == 4) "WhatsApp" else "Siguiente")
                        }
                    }
                }
            }
        }
    ) { padding ->
        // Al cambiar de paso, muestra su contenido desde el inicio.
        key(paso) {
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Paso ${paso + 1} de 5", color = MaterialTheme.colorScheme.primary)
                Text(titulos[paso], style = MaterialTheme.typography.headlineSmall)
                when (paso) {
                    // Primer paso: buscar y seleccionar una figura.
                    0 -> {
                        Text("Placas de acero inoxidable con grabado láser. Precio del catálogo web: $110 MXN por pieza.")
                        OutlinedTextField(value = busqueda, onValueChange = { busqueda = it },
                            label = { Text("Buscar figura") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Text("Categoría")
                        Column {
                            categorias.forEach { cat ->
                                TextButton(onClick = { categoria = cat }) {
                                    Text((if (categoria == cat) "● " else "○ ") + when (cat) {
                                        "clasica" -> "Clásicas"
                                        "troquelada" -> "Con troquelado"
                                        "animal" -> "Figuras de animal"
                                        else -> "Todas"
                                    })
                                }
                            }
                        }
                        // Filtra las figuras según el texto y la categoría.
                        val visibles = Catalogo.piezas.withIndex().filter { (_, pieza) ->
                            pieza.nombre.contains(busqueda.trim(), ignoreCase = true) &&
                                (categoria == "Todas" || pieza.categoria == categoria)
                        }
                        Text("${visibles.size} figuras disponibles")
                        if (visibles.isEmpty()) {
                            Text("No encontramos figuras.")
                            TextButton(onClick = { busqueda = ""; categoria = "Todas" }) { Text("Limpiar filtros") }
                        }
                        visibles.forEach { (i, pieza) ->
                            Opcion(pieza.nombre, "$110 MXN · ${pieza.categoria} · Sin fotografía",
                                p.pieza == i) { actualizar(p.copy(pieza = i)) }
                        }
                    }
                    // Segundo paso: escribir el nombre y elegir la tipografía.
                    1 -> {
                        Text(Catalogo.piezas.getOrNull(p.pieza)?.nombre ?: "Selecciona primero una figura")
                        OutlinedTextField(value = p.mascota, onValueChange = {
                            actualizar(p.copy(mascota = it.replace("\n", "").replace("\r", "").take(18)))
                        }, label = { Text("Nombre de la mascota") }, supportingText = {
                            Text(if (p.mascota.isBlank()) "Escribe un nombre para continuar. Máximo 18 caracteres." else "${p.mascota.length}/18 caracteres")
                        }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(20.dp)) {
                                Text("Vista previa del nombre")
                                Text(p.mascota.ifBlank { "Tu mascota" }, fontSize = 32.sp,
                                    fontFamily = FontFamily(Font(Catalogo.letras[p.letra.coerceIn(Catalogo.letras.indices)].recurso)),
                                    color = MaterialTheme.colorScheme.primary)
                                Text("Referencia de letra; no representa el tamaño o grabado final.", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Text("Selecciona una tipografía")
                        Catalogo.letras.forEachIndexed { i, letra ->
                            Card(onClick = { actualizar(p.copy(letra = i)) }, modifier = Modifier.fillMaxWidth(),
                                border = BorderStroke(1.dp, if (p.letra == i) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)) {
                                Column(Modifier.padding(14.dp)) {
                                    Text((if (p.letra == i) "● " else "○ ") + letra.nombre)
                                    Text(p.mascota.ifBlank { "Luna" }, fontSize = 26.sp, fontFamily = FontFamily(Font(letra.recurso)))
                                }
                            }
                        }
                    }
                    // Tercer paso: elegir cuántas placas se van a solicitar.
                    2 -> {
                        Text("Todas las piezas de esta solicitud tendrán la misma figura, nombre y tipografía.")
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            OutlinedButton(onClick = { actualizar(p.copy(cantidad = p.cantidad - 1)) }, enabled = p.cantidad > 1) { Text("−") }
                            Text("${p.cantidad}", Modifier.padding(top = 12.dp), fontSize = 24.sp)
                            Button(onClick = { actualizar(p.copy(cantidad = p.cantidad + 1)) }, enabled = p.cantidad < 99) { Text("+") }
                        }
                        Text("De 1 a 99 piezas. Precio unitario: $110 MXN.")
                        Text("Subtotal estimado: $${p.total} MXN", style = MaterialTheme.typography.titleLarge)
                    }
                    // Cuarto paso: capturar los datos de contacto del cliente.
                    3 -> {
                        Text("Estos datos son para la consulta al negocio; no se graban en la placa.")
                        OutlinedTextField(p.nombre, { actualizar(p.copy(nombre = it.take(80))) },
                            label = { Text("Nombre del cliente") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                            supportingText = { Text("Obligatorio") })
                        OutlinedTextField(p.telefono, { actualizar(p.copy(telefono = it.filter { c -> c in '0'..'9' }.take(10))) },
                            label = { Text("Teléfono de contacto") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            supportingText = { Text("10 dígitos para un número de México") })
                        OutlinedTextField(p.correo, { actualizar(p.copy(correo = it.take(120))) },
                            label = { Text("Correo electrónico") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            supportingText = { Text("Escribe un correo válido para continuar") })
                        Text("El borrador se guarda en este dispositivo. Reiniciar elimina los datos de la solicitud.", style = MaterialTheme.typography.bodySmall)
                    }
                    // Último paso: revisar la información antes de abrir WhatsApp.
                    4 -> {
                        Text(p.resumen(), style = MaterialTheme.typography.bodyLarge)
                        Text("Se abrirá WhatsApp para revisar y enviar el mensaje. Abrirlo no confirma un pedido ni un pago.")
                        if (WHATSAPP_NEGOCIO.isBlank()) Text("No se ha configurado el número del negocio: elige el chat correcto en WhatsApp.")
                        OutlinedButton(onClick = {
                            // Copia el resumen para poder pegarlo en otra aplicación.
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Cotización Marcando Huella", p.resumen()))
                            Toast.makeText(context, "Resumen copiado", Toast.LENGTH_SHORT).show()
                        }) { Text("Copiar resumen") }
                        Text("Usa Regresar para corregir los datos. El borrador se conserva al volver de WhatsApp.")
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

// Abre el enlace con el mensaje preparado para WhatsApp.
private fun abrirWhatsApp(context: Context, resumen: String) {
    val uri = Uri.parse("https://wa.me/${WHATSAPP_NEGOCIO}?text=${Uri.encode(resumen)}")
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
    // Avisa si no hay una aplicación que pueda abrir el enlace.
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(context, "No hay una app disponible. Usa Copiar resumen.", Toast.LENGTH_LONG).show()
    }
}


// Datos de ejemplo: las previews no crean ViewModels ni abren SharedPreferences.
@Preview(name = "1 Figura", showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun FiguraPreview() = PreviewPaso(0)

@Preview(name = "2 Personalización", showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun PersonalizacionPreview() = PreviewPaso(1)

@Preview(name = "3 Cantidad", showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun CantidadPreview() = PreviewPaso(2)

@Preview(name = "4 Cliente", showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun ClientePreview() = PreviewPaso(3)

@Preview(name = "5 Resumen", showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun ResumenPreview() = PreviewPaso(4)

@Composable
// Usa datos de ejemplo para ver las pantallas en Android Studio.
private fun PreviewPaso(pasoInicial: Int) {
    var pedido by remember {
        mutableStateOf(Pedido(
            pieza = 13, mascota = "Luna", letra = 9, cantidad = 3,
            nombre = "Daniel", telefono = "5512345678", correo = "daniel@example.com"
        ))
    }
    var paso by remember { mutableStateOf(pasoInicial) }
    MarcandoHuellaTheme {
        MarcandoHuellaContenido(
            p = pedido, paso = paso,
            actualizar = { pedido = it },
            ir = { paso = it.coerceIn(0, 4) },
            reiniciar = { pedido = Pedido(); paso = 0 }
        )
    }
}
```

### app/src/main/java/com/ebc/marcandohuella/ui/theme/Theme.kt

```kotlin
package com.ebc.marcandohuella.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
// Define los colores que se tomaron del sitio web.
private val Colores = darkColorScheme(
 primary=Color(0xFF0EE1E5), onPrimary=Color(0xFF070B0D),
 background=Color(0xFF070B0D), onBackground=Color(0xFFF7FAF9),
 surface=Color(0xFF101719), onSurface=Color(0xFFF7FAF9),
 surfaceVariant=Color(0xFF172124), onSurfaceVariant=Color(0xFFAEBCBC),
 secondary=Color(0xFF609DF3)
)
// Aplica los mismos colores a todas las pantallas.
@Composable fun MarcandoHuellaTheme(content: @Composable () -> Unit) {
 MaterialTheme(colorScheme=Colores, content=content)
}
```

### app/src/main/java/com/ebc/marcandohuella/viewmodel/PedidoViewModel.kt

```kotlin
package com.ebc.marcandohuella.viewmodel
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import com.ebc.marcandohuella.model.Pedido
import org.json.JSONObject
// Conserva los datos mientras el usuario cambia de pantalla.
class PedidoViewModel(app: Application) : AndroidViewModel(app) {
 // Usa un archivo privado para guardar el borrador en el dispositivo.
 private val prefs = app.getSharedPreferences("borrador", 0)
 // Carga el pedido guardado o crea uno vacío.
 var pedido by mutableStateOf(leer()); private set
 // Indica cuál de los cinco pasos se está mostrando.
 var paso by mutableStateOf(0); private set
 // Recupera el borrador. Si no se puede leer, usa un pedido vacío.
 private fun leer(): Pedido = runCatching {
  val j = JSONObject(prefs.getString("pedido", "{}") ?: "{}")
  Pedido(j.optInt("pieza", -1), j.optString("mascota"), j.optInt("letra", 0), j.optInt("cantidad", 1).coerceIn(1,99), j.optString("nombre"), j.optString("telefono"), j.optString("correo"))
 }.getOrDefault(Pedido())
 // Actualiza la pantalla y guarda los cambios del pedido.
 fun actualizar(p: Pedido) {
  pedido=p
  val j=JSONObject().put("pieza",p.pieza).put("mascota",p.mascota).put("letra",p.letra).put("cantidad",p.cantidad).put("nombre",p.nombre).put("telefono",p.telefono).put("correo",p.correo)
  prefs.edit().putString("pedido",j.toString()).apply()
 }
 // Cambia de paso sin salir del rango de pantallas.
 fun ir(p: Int) { paso=p.coerceIn(0,4) }
 // Borra los datos del pedido y vuelve al primer paso.
 fun reiniciar() { actualizar(Pedido()); paso=0 }
}
```

### app/src/test/java/com/ebc/marcandohuella/PedidoTest.kt

```kotlin
package com.ebc.marcandohuella

import com.ebc.marcandohuella.model.Catalogo
import com.ebc.marcandohuella.model.Pedido
import org.junit.Assert.*
import org.junit.Test

class PedidoTest {
    @Test fun catalogoConservaFigurasPrecioYFuentes() {
        assertEquals(17, Catalogo.piezas.size)
        assertEquals(12, Catalogo.letras.size)
        assertEquals(110, Catalogo.PRECIO)
        assertEquals(17, Catalogo.piezas.map { it.id }.distinct().size)
    }
    @Test fun tresPiezasCuestan330() {
        assertEquals(330, Pedido(cantidad = 3).total)
    }
    @Test fun placaRequiereFiguraNombreYLetraValida() {
        assertFalse(Pedido().placaValida)
        assertFalse(Pedido(pieza = 0, mascota = "  ").placaValida)
        assertFalse(Pedido(pieza = 0, mascota = "a".repeat(19)).placaValida)
        assertFalse(Pedido(pieza = 17, mascota = "Luna").placaValida)
        assertFalse(Pedido(pieza = 0, mascota = "Luna", letra = 12).placaValida)
        assertTrue(Pedido(pieza = 0, mascota = "Luna", letra = 0).placaValida)
    }
    @Test fun resumenConservaDisenoCantidadYDatosSinAfirmarCompra() {
        val p = Pedido(pieza = 13, mascota = "Luna", letra = 9, cantidad = 3,
            nombre = "Daniel", telefono = "5512345678", correo = "daniel@example.com")
        val resumen = p.resumen()
        listOf("Redondo mediano", "Luna", "Montserrat", "Cantidad: 3", "330 MXN", "Daniel", "5512345678", "daniel@example.com")
            .forEach { assertTrue(it, resumen.contains(it)) }
        assertFalse(resumen.contains("Pedido confirmado"))
    }
}
```
